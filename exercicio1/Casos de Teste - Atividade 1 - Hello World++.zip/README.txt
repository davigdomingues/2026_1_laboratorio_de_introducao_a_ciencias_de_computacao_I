Arquivo zip gerado em: 19/01/2026 14:45:26 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Atividade 1 - Hello World++